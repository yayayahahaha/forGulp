window.onload = function() {
	var toggle = document.querySelector('#toggleId');
	
	/*toggleInout function example*/
	toggleInput(toggle,"red");

	/* whichBrowser function example */
	console.log("whichBrowser function example: ",whichBrowser());

}